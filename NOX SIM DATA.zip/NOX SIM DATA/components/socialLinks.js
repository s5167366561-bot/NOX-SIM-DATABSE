const LINKS = [
  {
    label: 'WhatsApp Channel',
    url: 'https://whatsapp.com/channel/0029Vb8AWXqDZ4LhJ1C5ch2H',
    icon: 'fa-brands fa-whatsapp',
    cls: 'wa',
  },
  {
    label: 'Telegram Main',
    url: 'https://t.me/shadowxlegend12',
    icon: 'fa-brands fa-telegram',
    cls: 'tg',
  },
  {
    label: 'Telegram Free',
    url: 'https://t.me/malikfreeshh',
    icon: 'fa-brands fa-telegram',
    cls: 'tg',
  },
  {
    label: 'Facebook',
    url: 'https://www.facebook.com/share/1C3Tca6UNc/',
    icon: 'fa-brands fa-facebook-f',
    cls: 'fb',
  },
  {
    label: 'TikTok',
    url: 'https://www.tiktok.com/@shadows_133?_r=1&_t=ZN-9AQk8A1yZq2',
    icon: 'fa-brands fa-tiktok',
    cls: 'tt',
  },
];

export default function SocialLinks() {
  return (
    <section className="social-section">
      <h3 className="social-title">Connect With Us</h3>
      <div className="social-grid">
        {LINKS.map((l, i) => (
          <a
            key={i}
            href={l.url}
            target="_blank"
            rel="noopener noreferrer"
            className="social-btn"
          >
            <span className={`s-icon-wrap ${l.cls}`}>
              <i className={l.icon}></i>
            </span>
            <span className="s-label">{l.label}</span>
          </a>
        ))}
      </div>
    </section>
  );
}