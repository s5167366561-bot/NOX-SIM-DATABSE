'use client';

import { useState, useRef, useEffect } from 'react';

export default function SearchCard() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultHtml, setResultHtml] = useState(null);
  const [toast, setToast] = useState('');
  const [toastShow, setToastShow] = useState(false);

  const inputRef = useRef(null);
  const toastTimer = useRef(null);

  const showToast = (msg) => {
    setToast(msg);
    setToastShow(true);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastShow(false), 1800);
  };

  const clearSearch = () => {
    setQuery('');
    inputRef.current?.focus();
  };

  // Flatten object
  const flattenObject = (ob, prefix = '') => {
    let out = {};
    if (typeof ob !== 'object' || ob === null) return out;
    for (let i in ob) {
      if (!Object.prototype.hasOwnProperty.call(ob, i)) continue;
      let k = prefix ? `${prefix}_${i}` : i;
      let v = ob[i];
      if (v !== null && typeof v === 'object') {
        if (Array.isArray(v)) {
          v.forEach((item, idx) => {
            if (typeof item === 'object' && item !== null) {
              Object.assign(out, flattenObject(item, `${k}_${idx + 1}`));
            } else {
              out[`${k}_${idx + 1}`] = item;
            }
          });
        } else {
          Object.assign(out, flattenObject(v, k));
        }
      } else {
        out[k] = v;
      }
    }
    return out;
  };

  const extractAllRecords = (data) => {
    let found = [];
    if (!data) return found;
    let root = data;
    if (typeof data === 'string') {
      try {
        root = JSON.parse(data);
      } catch {
        root = { result: data };
      }
    }
    let payload =
      root.data ||
      root.result ||
      root.results ||
      root.records ||
      root.response ||
      root.sim_data ||
      root;

    let rawList = [];
    if (Array.isArray(payload)) {
      payload.forEach((item) => {
        const flat = flattenObject(item);
        if (Object.keys(flat).length > 0) rawList.push(flat);
      });
    } else if (typeof payload === 'object' && payload !== null) {
      const flat = flattenObject(payload);
      if (Object.keys(flat).length > 0) rawList.push(flat);
    }

    rawList.forEach((rec) => {
      let groups = {};
      let hasPrefixed = false;

      for (let [key, val] of Object.entries(rec)) {
        if (val === null || val === undefined || val === '') continue;

        const m1 = key.match(
          /(?:truecaller\s*data|sim\s*details?|details?|data|rec|record|result|user|sim)?[\s_:-]*(\d+)[\s_:-]+(.*)/i
        );
        const m2 = key.match(/^(.+?)[\s_:-]*(\d+)$/i);
        const isMeta =
          /^(query|raw|local|status|success|message|code)/i.test(key) ||
          /query\s*raw|query\s*local/i.test(key);

        if (!isMeta && m1 && m1[1] && m1[2]) {
          hasPrefixed = true;
          const g = m1[1];
          const f =
            m1[2]
              .replace(
                /^(?:truecaller\s*data|sim\s*details?|details?|data|rec|record|result|user|sim)[\s_:-]*/i,
                ''
              )
              .trim() || key;
          if (!groups[g]) groups[g] = {};
          groups[g][f] = val;
        } else if (!isMeta && m2 && m2[1] && m2[2]) {
          hasPrefixed = true;
          const f =
            m2[1]
              .replace(
                /^(?:truecaller\s*data|sim\s*details?|details?|data|rec|record|result|user|sim)[\s_:-]*/i,
                ''
              )
              .trim() || key;
          const g = m2[2];
          if (!groups[g]) groups[g] = {};
          groups[g][f] = val;
        }
      }

      if (hasPrefixed && Object.keys(groups).length > 0) {
        Object.keys(groups)
          .sort((a, b) => parseInt(a) - parseInt(b))
          .forEach((g) => {
            if (Object.keys(groups[g]).length > 0) found.push(groups[g]);
          });
      } else {
        found.push(rec);
      }
    });

    return found;
  };

  const renderFields = (obj) => {
    let html = '';
    const skip = ['status', 'success', 'message', 'query_used', 'server_used', 'code', 'cached'];

    for (let [key, val] of Object.entries(obj)) {
      let ck = key.toLowerCase().trim();
      ck = ck
        .replace(
          /^(?:truecaller\s*data|truecaller|true_caller|sim\s*details?|details?|data|rec|record)[\s_:-]*\d*[\s_:-]*/i,
          ''
        )
        .trim();

      if (skip.includes(ck) && Object.keys(obj).length > 2) continue;

      let dk = ck.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());

      if (['nbr', 'number'].includes(ck) || ck.endsWith(' nbr') || ck.endsWith(' number'))
        dk = 'Number';
      else if (['nam', 'name'].includes(ck) || ck.endsWith(' nam') || ck.endsWith(' name'))
        dk = 'Name';
      else if (['cni', 'cnic'].includes(ck) || ck.endsWith(' cni') || ck.endsWith(' cnic'))
        dk = 'CNIC';
      else if (['adr', 'address'].includes(ck) || ck.endsWith(' adr') || ck.endsWith(' address'))
        dk = 'Address';

      const isNum =
        ck.includes('nbr') || ck.includes('num') || ck.includes('phone') || ck.includes('mobile');

      html += `
        <div class="field-row">
          <span class="field-key">${dk}:</span>
          <span class="field-val ${isNum ? 'num' : ''}">${
        val !== null && val !== undefined ? val : 'N/A'
      }</span>
        </div>`;
    }
    return html;
  };

  const renderResults = (records) => {
    if (!records || records.length === 0) {
      return `
        <div class="no-rec">
          <i class="fa-solid fa-database"></i>
          <h4>No Records Found</h4>
          <p>Try a different number</p>
        </div>`;
    }

    let recordsHtml = '';
    let hasAny = false;

    records.forEach((rec, idx) => {
      const f = renderFields(rec);
      if (f.trim() !== '') {
        hasAny = true;
        recordsHtml += `
          <div class="rec-card" style="animation-delay:${idx * 0.07}s;">
            <div class="rec-head">
              <span class="rec-idx"><span class="bar"></span>Record #${idx + 1}</span>
              <button type="button" data-copy="1" class="copy-btn">
                <i class="fa-regular fa-copy"></i> Copy
              </button>
            </div>
            <div>${f}</div>
          </div>`;
      }
    });

    if (!hasAny) {
      return `
        <div class="no-rec">
          <i class="fa-solid fa-database"></i>
          <h4>No Records Found</h4>
          <p>Try a different number</p>
        </div>`;
    }

    return `
      <div class="rec-total">Total Records ( ${records.length} )</div>
      <div>${recordsHtml}</div>`;
  };

  const executeSearch = async (e) => {
    e.preventDefault();
    if (!query.trim() || loading) return;

    setLoading(true);
    setResultHtml(`
      <div class="loader-card">
        <i class="fa-solid fa-circle-notch fa-spin"></i>
        <p>Fetching data...</p>
      </div>`);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const res = await fetch(
        `https://ft-simdb.ftshehryar10044.workers.dev/ft/api?num=${encodeURIComponent(
          query.trim()
        )}`,
        { signal: controller.signal }
      );
      clearTimeout(timeoutId);
      const data = await res.json();
      const records = extractAllRecords(data);
      setResultHtml(renderResults(records));
    } catch (err) {
      setResultHtml(`
        <div class="no-rec">
          <i class="fa-solid fa-triangle-exclamation"></i>
          <h4>Network Error</h4>
          <p>Could not reach server. Try again later.</p>
        </div>`);
    }

    setLoading(false);
  };

  // copy handler via event delegation
  useEffect(() => {
    const box = document.getElementById('resultBox');
    if (!box) return;
    const handler = (e) => {
      const btn = e.target.closest('[data-copy]');
      if (!btn) return;
      const card = btn.closest('.rec-card');
      if (!card) return;
      navigator.clipboard.writeText(card.innerText).then(() => {
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
        setTimeout(() => {
          btn.innerHTML = orig;
        }, 1500);
      });
    };
    box.addEventListener('click', handler);
    return () => box.removeEventListener('click', handler);
  }, []);

  return (
    <>
      <div className="card">
        <h2>
          <span className="h2-icon">
            <i className="fa-solid fa-magnifying-glass"></i>
          </span>
          Search Number Details
        </h2>

        <form onSubmit={executeSearch}>
          <div className="search-shell">
            <div className="search-inner">
              <div className="s-icon">
                <i className="fa-solid fa-magnifying-glass"></i>
              </div>
              <input
                ref={inputRef}
                type="text"
                className="search-input"
                placeholder="NUMBER OR CNIC"
                required
                autoComplete="off"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <button
                type="button"
                className={`clear-btn ${query ? 'show' : ''}`}
                onClick={clearSearch}
                aria-label="Clear"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
          </div>

          <div
            id="resultBox"
            dangerouslySetInnerHTML={{
              __html:
                resultHtml ??
                `
              <div class="loader-card" style="border-style:solid;border-color:#1e293b;background:rgba(7,10,18,0.4);">
                <i class="fa-solid fa-database" style="opacity:.4;"></i>
                <p style="color:#5c6b85;">ENTER A NUMBER ABOVE TO SEARCH DETAILS</p>
              </div>`,
            }}
          />

          <div className="pill-stack">
            <button type="submit" className="pill pill-primary" disabled={loading}>
              <span className="pill-icon">
                <i className={`fa-solid ${loading ? 'fa-circle-notch fa-spin' : 'fa-bolt'}`}></i>
              </span>
              {loading ? 'Searching...' : 'Search Data'}
            </button>
          </div>
        </form>
      </div>

      <div className={`toast ${toastShow ? 'show' : ''}`}>{toast}</div>
    </>
  );
}